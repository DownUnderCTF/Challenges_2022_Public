#!/bin/sh
while true; do
    node /app/index.js
done
